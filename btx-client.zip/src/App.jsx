import React from 'react';
import AppRoutes from './routes/route';
import './tailwind.css';

function App() {
  return (
    <div>
      <AppRoutes />
    </div>
  );
}

export default App;