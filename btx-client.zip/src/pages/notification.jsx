import React, { useEffect, useState } from "react";
import Table from "../component/NotificationTable";
// import { Button } from "@/components/ui/button";
// import { useMutation } from "react-query";
// import axios from "axios";

const Notification = () => {
    const [formData, setFormData] = useState({ name: '', message: '', image: null });
    const [rows, setRows] = useState([]);

    const headers = ["Name", "message", "Image", "date"];

    useEffect(() => {
        fetch('https://blockchain.eastasia.cloudapp.azure.com/get_notifications')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                setRows(data.data);
                setLoading(false);
            })
            .catch(error => {
                setError(error.message);
                setLoading(false);
            });
    }, []);

    // const addNotification = async (formData) => {
    //     const data = new FormData();
    //     data.append('name', formData.name);
    //     data.append('message', formData.message);
    //     if (formData.image) {
    //         data.append('image', formData.image);
    //     }
    //     try {
    //         fetch('https://wave-backend-zulg.onrender.com/add_notification', {
    //             method: 'POST',
    //             body: formData
    //         })
    //             .then(response => {
    //                 if (!response.ok) {
    //                     throw new Error('Network response was not ok');
    //                 }
    //                 return response.json();
    //             })
    //             .then(responseData => {
    //                 if (responseData.success) {
    //                     alert(responseData.message);
    //                 } else {
    //                     return undefined;
    //                 }
    //             })
    //             .catch(error => {
    //                 console.log("Error", error);
    //             });

    //     } catch (error) {
    //         console.log("Error", error)

    //     }
    // };

    // const handleChange = (e) => {
    //     const { name, value, files } = e.target;
    //     if (files && files[0]) {
    //         setFormData(prevFormData => ({
    //             ...prevFormData,
    //             [name]: files && files.length > 0 ? files[0] : value
    //         }));
    //     } else {
    //         setFormData(prevFormData => ({
    //             ...prevFormData,
    //             [name]: value
    //         }));
    //     }
    // };


    // const handleSubmit = async (e) => {
    //     e.preventDefault();
    //     try {
    //         await addNotification(formData);
    //     } catch (error) {
    //         console.error("Error while submitting notification:", error);
    //     }
    // };

    return (
        <>
            <Table rows={rows} headers={headers} />
        </>
    );
};

export default React.memo(Notification);

